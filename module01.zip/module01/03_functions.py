# Functions


def factorial(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def even_or_odd(n):
    return "Even" if n % 2 == 0 else "Odd"


if __name__ == "__main__":
    print("Factorial of 5:", factorial(5))
    for num in (2, 15, 17, 20):
        print(num, "is prime:", is_prime(num))
    print("10 is", even_or_odd(10))
    print("7 is", even_or_odd(7))
