# Loops: for and while

# Multiplication table using a for loop
number = 7
print(f"Multiplication table of {number}")
for i in range(1, 11):
    print(f"{number} x {i} = {number * i}")

# Sum of 1..100 using a while loop
total = 0
n = 1
while n <= 100:
    total += n
    n += 1
print("\nSum of 1 to 100:", total)

# Countdown
print("\nCountdown:")
for i in range(5, 0, -1):
    print(i)
print("Go!")
