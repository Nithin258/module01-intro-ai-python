# Student grade calculator


def calculate_grade(average):
    if average >= 90:
        return "A+"
    elif average >= 80:
        return "A"
    elif average >= 70:
        return "B"
    elif average >= 60:
        return "C"
    elif average >= 50:
        return "D"
    return "F"


def main():
    subjects = ["Maths", "Python", "Statistics", "AI Basics", "Databases"]
    marks = []
    for subject in subjects:
        while True:
            try:
                m = float(input(f"Enter marks for {subject} (0-100): "))
                if 0 <= m <= 100:
                    marks.append(m)
                    break
                print("Marks must be between 0 and 100.")
            except ValueError:
                print("Enter a number.")

    average = sum(marks) / len(marks)
    print(f"\nTotal: {sum(marks)} / {len(marks) * 100}")
    print(f"Average: {average:.2f}")
    print("Grade:", calculate_grade(average))


if __name__ == "__main__":
    main()
