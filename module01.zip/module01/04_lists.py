# Lists

marks = [78, 85, 92, 66, 88]
print("Marks:", marks)

marks.append(95)
print("After append:", marks)

marks.remove(66)
print("After remove:", marks)

marks.sort()
print("Sorted:", marks)

print("First:", marks[0], "| Last:", marks[-1])
print("Highest:", max(marks))
print("Lowest:", min(marks))
print("Average:", round(sum(marks) / len(marks), 2))

# List comprehension: squares of even numbers up to 10
squares = [x ** 2 for x in range(1, 11) if x % 2 == 0]
print("Squares of evens:", squares)
