# Variables and data types in Python

name = "Karthik"          # str
age = 21                  # int
cgpa = 8.5                # float
is_student = True         # bool
skills = ["Python", "SQL", "Machine Learning"]  # list

print("Name:", name)
print("Age:", age)
print("CGPA:", cgpa)
print("Is student:", is_student)
print("Skills:", skills)

for value in (name, age, cgpa, is_student, skills):
    print(value, "->", type(value).__name__)
