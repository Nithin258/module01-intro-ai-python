# Module 01 – Introduction to AI & Python

Internship: Data Science / AI – Codomax Digital Solutions
Module: 01 (Day 1 – Day 4)

## Objectives covered
1. Basics of Artificial Intelligence and Machine Learning
2. Difference between AI, ML and Deep Learning
3. Real-world AI applications
4. Python setup and core concepts (variables, loops, functions, lists)
5. Beginner-friendly Python programs

## Repository structure
```
.
├── README.md
├── learning_notes.md
├── 01_variables_and_types.py
├── 02_loops.py
├── 03_functions.py
├── 04_lists.py
├── 05_number_guessing_game.py
└── 06_student_grade_calculator.py
```

## How to run
1. Install Python 3.10+ from https://www.python.org/downloads/
2. Verify: `python --version`
3. Run any program: `python 01_variables_and_types.py`

## Programs
| File | Concept | What it does |
|------|---------|--------------|
| 01_variables_and_types.py | Variables, data types | Stores and prints different data types |
| 02_loops.py | for / while loops | Multiplication table, sum, countdown |
| 03_functions.py | Functions | Reusable functions: factorial, prime check, even/odd |
| 04_lists.py | Lists | List operations, min/max/average |
| 05_number_guessing_game.py | Loops + conditions | Guess the secret number |
| 06_student_grade_calculator.py | Lists + functions | Computes average and grade |

## Author
Karthik – B.Tech Artificial Intelligence & Data Science
