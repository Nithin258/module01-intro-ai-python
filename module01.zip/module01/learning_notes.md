# Learning Notes – Module 01: Introduction to AI & Python (Day 1 – Day 4)

## 1. Artificial Intelligence (AI)
AI is the field of building systems that perform tasks normally requiring human intelligence: learning, reasoning, perception, language understanding and decision-making.

## 2. Machine Learning (ML)
ML is a subset of AI where systems learn patterns from data instead of being explicitly programmed.

| Type | Description | Example |
|------|-------------|---------|
| Supervised | Learns from labeled data | Spam detection, house price prediction |
| Unsupervised | Finds structure in unlabeled data | Customer segmentation |
| Reinforcement | Learns via rewards and penalties | Game-playing agents, robotics |

## 3. Deep Learning (DL)
DL is a subset of ML that uses multi-layer neural networks. It excels with large datasets and unstructured data such as images, audio and text.

## 4. AI vs ML vs DL
AI ⊃ ML ⊃ DL
- **AI**: the broad goal of intelligent machines
- **ML**: learning from data to achieve that goal
- **DL**: learning with deep neural networks

| Aspect | AI | ML | DL |
|--------|----|----|----|
| Scope | Broadest | Subset of AI | Subset of ML |
| Data need | Varies | Moderate | Very large |
| Feature engineering | Varies | Often manual | Automatic |
| Example | Chess engine | Fraud detection | Face recognition |

## 5. Real-World AI Applications
- **Healthcare**: disease detection from medical images
- **Finance**: fraud detection, credit scoring
- **E-commerce**: recommendation engines
- **Transport**: self-driving cars, route optimization
- **Education**: personalized learning, chatbots
- **Language**: translation, voice assistants, generative AI

## 6. Python Setup
1. Download Python from python.org and tick "Add Python to PATH".
2. Check with `python --version`.
3. Use VS Code, IDLE, or Jupyter/Google Colab as the editor.

## 7. Python Fundamentals
**Variables & types**: `int`, `float`, `str`, `bool`, `list` – Python is dynamically typed.

**Loops**
```python
for i in range(5): print(i)
while condition: ...
```

**Functions**
```python
def add(a, b):
    return a + b
```

**Lists**: ordered, mutable; methods include `append`, `remove`, `sort`; supports indexing, slicing and list comprehensions.

## 8. Programs Practised
Variables and types, loops, functions (factorial, prime check), list operations, number guessing game, student grade calculator.

## 9. Key Takeaways
- AI is the umbrella; ML and DL are progressively specialised.
- Python is the standard language for AI/ML thanks to simple syntax and libraries (NumPy, pandas, scikit-learn, TensorFlow, PyTorch).
- Practising small programs builds the logic needed for data science work.

## 10. Challenges & Next Steps
- Practise input validation and edge cases.
- Move on to Module 02: a Python mini project applying these concepts.
